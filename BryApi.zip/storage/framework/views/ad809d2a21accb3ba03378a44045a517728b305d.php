<div class="btn-group" role="group" aria-label="Basic mixed styles example">
    <a href="/action/criar/<?php echo e($model); ?>/" class="btn btn-success">
        <span class="fa fa-user-plus"></span> Criar novo
    </a>
  </div>
<?php /**PATH C:\projetos\BryApi\resources\views/bootstrap/actionbar.blade.php ENDPATH**/ ?>