<header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">
    <a href="/crud" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
      <span class="fs-4">Crud Laravel</span>
    </a>
    <ul class="nav nav-pills">
      <li class="nav-item"><a href="/" class="nav-link" aria-current="page">Inicio</a></li>
      <li class="nav-item"><a href="/crudempresas" class="nav-link">Empresas</a></li>
      <li class="nav-item"><a href="/crudfuncionarios" class="nav-link">Funcionários</a></li>
      <li class="nav-item"><a href="/crudclientes" class="nav-link">Clientes</a></li>
      <li class="nav-item"><a href="#" class="nav-link">Documentação</a></li>
    </ul>
  </header>
<?php /**PATH C:\projetos\BryApi\resources\views\bootstrap\menuheader.blade.php ENDPATH**/ ?>