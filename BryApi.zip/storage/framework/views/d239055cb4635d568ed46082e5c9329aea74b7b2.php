<?php $__env->startSection("body"); ?>
<div class="container">
    <?php echo $__env->make("bootstrap.menuheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("bootstrap.actionbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <table class="table table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Nome</th>
            <th scope="col">E-mail</th>
            <th scope="col">CPF</th>
            <th scope="col">Endereço</th>
            <th scope="col">Ações</th>
          </tr>
        </thead>
        <tbody>
            <?php $n = 1; ?>
            <?php $__currentLoopData = $funcionarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td scope="col"><?php echo e($n); ?></td>
                <td scope="col"><?php echo e($v["nome"]); ?></td>
                <td scope="col"><?php echo e($v["email"]); ?></td>
                <td scope="col"><?php echo e($v["cpf"]); ?></td>
                <td scope="col"><?php echo e($v["endereco"]); ?></td>
                <td scope="col">
                    <a href="/action/delete/<?php echo e($v["id"]); ?>/funcionario" class="btn btn-danger" alt="excluir">
                        <span class="fa fa-trash"></span>
                    </a>
                    <a href="/action/edit/<?php echo e($v["id"]); ?>/funcionario" class="btn btn-primary" alt="excluir">
                        <span class="fa fa-edit"></span>
                    </a>
                </td>
              </tr>
              <?php $n++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
</div>
<div class="row container d-flex flex-wrap justify-content-center">


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("bootstrap.model", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\BryApi\resources\views/bootstrap/funcionariolist.blade.php ENDPATH**/ ?>