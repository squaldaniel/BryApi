<?php $__env->startSection("body"); ?>
<div class="container">
    <?php echo $__env->make("bootstrap.menuheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <table class="table table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Nome</th>
            <th scope="col">E-mail</th>
            <th scope="col">CPF</th>
            <th scope="col">Endereço</th>
          </tr>
        </thead>
        <tbody>
            <?php $n = 1; ?>
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="col"><?php echo e($n); ?></th>
                <th scope="col"><?php echo e($v["nome"]); ?></th>
                <th scope="col"><?php echo e($v["email"]); ?></th>
                <th scope="col"><?php echo e($v["cpf"]); ?></th>
                <th scope="col"><?php echo e($v["endereco"]); ?></th>
              </tr>
              <?php $n++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
</div>
<div class="row container d-flex flex-wrap justify-content-center">


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("bootstrap.model", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\BryApi\resources\views\bootstrap\clientelist.blade.php ENDPATH**/ ?>