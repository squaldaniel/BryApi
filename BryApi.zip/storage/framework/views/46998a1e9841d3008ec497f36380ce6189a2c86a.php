<?php $__env->startSection("body"); ?>
<div class="container">
    <?php echo $__env->make("bootstrap.menuheader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Empresas</th>
            <th scope="col">Funcionarios</th>
            <th scope="col">Clientes</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">1</th>
            <td><?php echo e($dados[0]->empresas); ?></td>
            <td><?php echo e($dados[0]->funcionarios); ?></td>
            <td><?php echo e($dados[0]->clientes); ?></td>
          </tr>
        </tbody>
      </table>
</div>
<div class="row container d-flex flex-wrap justify-content-center">




</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("bootstrap.model", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\BryApi\resources\views\bootstrap\crudindex.blade.php ENDPATH**/ ?>