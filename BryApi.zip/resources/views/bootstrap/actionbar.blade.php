<div class="btn-group" role="group" aria-label="Basic mixed styles example">
    <a href="/action/criar/{{$model}}/" class="btn btn-success">
        <span class="fa fa-user-plus"></span> Criar novo
    </a>
  </div>
